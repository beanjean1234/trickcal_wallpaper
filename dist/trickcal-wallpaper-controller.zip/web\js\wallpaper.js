(() => {
"use strict";

const { LENS, PARAMETERS } = (() => {
const LENS = Object.freeze({
  desktopWidth: 240,
  desktopHeight: 240,
  mobileWidth: 200,
  mobileHeight: 200,
  mobileBreakpoint: 760,
  cornerRadius: 18,
  mobileCornerRadius: 16,
  maxTilt: 30,
});

const PARAMETERS = Object.freeze({
  specularOpacity: 3,
  specularAngle: -60,
});

return { LENS, PARAMETERS };
})();

const { createBackgroundRenderer } = (() => {
const VERTEX_SHADER = `
attribute vec2 a_position;

void main() {
  gl_Position = vec4(a_position, 0.0, 1.0);
}
`;

const FRAGMENT_SHADER = `
precision highp float;

uniform vec2 u_resolution;

float hash(vec2 p) {
  return fract(
    sin(dot(p, vec2(127.1, 311.7))) * 43758.5453
  );
}

vec3 backdrop(vec2 uv) {
  vec3 base = mix(
    vec3(0.92, 0.975, 1.0),
    vec3(0.985, 0.995, 1.0),
    smoothstep(-0.8, 0.85, uv.y)
  );

  float cyan = exp(
    -5.0 * dot(
      uv - vec2(-0.88, 0.37),
      uv - vec2(-0.88, 0.37)
    )
  );

  float blue = exp(
    -7.0 * dot(
      uv - vec2(0.92, -0.36),
      uv - vec2(0.92, -0.36)
    )
  );

  float lilac = exp(
    -9.0 * dot(
      uv - vec2(0.38, 0.82),
      uv - vec2(0.38, 0.82)
    )
  );

  float halo = exp(
    -3.4 * dot(
      uv - vec2(0.22, 0.02),
      uv - vec2(0.22, 0.02)
    )
  );

  base = mix(base, vec3(0.12, 0.82, 0.98), cyan * 0.68);
  base = mix(base, vec3(0.27, 0.43, 0.98), blue * 0.42);
  base = mix(base, vec3(0.72, 0.50, 1.0), lilac * 0.22);
  base = mix(base, vec3(0.42, 0.90, 0.96), halo * 0.22);

  float line = smoothstep(
    0.018,
    0.0,
    abs(uv.y + 0.70 + 0.055 * sin(uv.x * 2.2))
  );

  base += line * vec3(0.08, 0.30, 0.43) * 0.09;
  base += (hash(gl_FragCoord.xy) - 0.5) / 255.0;

  return base;
}

void main() {
  vec2 frag = gl_FragCoord.xy;
  vec2 uv = (2.0 * frag - u_resolution.xy)
    / min(u_resolution.x, u_resolution.y);
  vec2 bgUv = uv * 0.62;
  vec3 backgroundColor = backdrop(bgUv);

  float vignette = smoothstep(
    1.8,
    0.15,
    length(bgUv)
  );

  backgroundColor *= 0.96 + 0.04 * vignette;
  gl_FragColor = vec4(backgroundColor, 1.0);
}
`;

function compileShader(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);

  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    const message = gl.getShaderInfoLog(shader);
    gl.deleteShader(shader);
    throw new Error(`Background shader compilation failed: ${message}`);
  }

  return shader;
}

function createProgram(gl) {
  const program = gl.createProgram();
  const vertexShader = compileShader(gl, gl.VERTEX_SHADER, VERTEX_SHADER);
  const fragmentShader = compileShader(gl, gl.FRAGMENT_SHADER, FRAGMENT_SHADER);

  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  gl.deleteShader(vertexShader);
  gl.deleteShader(fragmentShader);

  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
    const message = gl.getProgramInfoLog(program);
    gl.deleteProgram(program);
    throw new Error(`Background shader linking failed: ${message}`);
  }

  return program;
}

function createBackgroundRenderer(canvas) {
  const gl = canvas.getContext("webgl", {
    alpha: false,
    antialias: false,
    depth: false,
    powerPreference: "low-power",
  });

  if (!gl) return null;

  const program = createProgram(gl);
  const positionLocation = gl.getAttribLocation(program, "a_position");
  const resolutionLocation = gl.getUniformLocation(program, "u_resolution");
  const positionBuffer = gl.createBuffer();

  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
  gl.bufferData(
    gl.ARRAY_BUFFER,
    new Float32Array([
      -1, -1,
      1, -1,
      -1, 1,
      -1, 1,
      1, -1,
      1, 1,
    ]),
    gl.STATIC_DRAW,
  );

  gl.useProgram(program);
  gl.enableVertexAttribArray(positionLocation);
  gl.vertexAttribPointer(positionLocation, 2, gl.FLOAT, false, 0, 0);

  let renderFrame = null;

  const render = () => {
    renderFrame = null;
    const dpr = Math.min(window.devicePixelRatio || 1, 1.7);
    const width = Math.max(1, Math.floor(canvas.clientWidth * dpr));
    const height = Math.max(1, Math.floor(canvas.clientHeight * dpr));

    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
      gl.viewport(0, 0, width, height);
    }

    gl.useProgram(program);
    gl.uniform2f(resolutionLocation, width, height);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
  };

  const scheduleRender = () => {
    if (renderFrame === null) {
      renderFrame = window.requestAnimationFrame(render);
    }
  };

  const resizeObserver = new ResizeObserver(scheduleRender);
  resizeObserver.observe(canvas);
  window.addEventListener("resize", scheduleRender, { passive: true });
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) scheduleRender();
  });
  scheduleRender();

  return { render: scheduleRender };
}

return { createBackgroundRenderer };
})();

const { makeDraggableGroup } = (() => {
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

function getRightInset(container) {
  return Number.parseFloat(
    getComputedStyle(container).getPropertyValue("--interaction-right-inset"),
  ) || 0;
}

function clampPosition(element, container, left, top) {
  const containerRect = container.getBoundingClientRect();
  return {
    left: clamp(
      left,
      0,
      Math.max(0, containerRect.width - getRightInset(container) - element.offsetWidth),
    ),
    top: clamp(top, 0, Math.max(0, container.scrollHeight - element.offsetHeight)),
  };
}

function updateAriaValue(element, container, left) {
  const max = Math.max(
    1,
    container.clientWidth - getRightInset(container) - element.offsetWidth,
  );
  element.setAttribute("aria-valuenow", String(Math.round((left / max) * 100)));
}

function makeDraggableGroup(
  initialElements,
  container,
  { draggable = true, onPositionChange = () => {}, onSelectionChange = () => {} } = {},
) {
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
  const elements = [...initialElements];
  const dragStates = new Map();
  let pointerX = 0;
  let pointerY = 0;
  let pointerActive = false;
  let tiltFrame = null;
  let topLayer = 20;

  const setPointerInput = () => {
    document.documentElement.classList.add("is-pointer-input");
  };
  const setKeyboardInput = () => {
    document.documentElement.classList.remove("is-pointer-input");
  };

  const renderTilt = () => {
    tiltFrame = null;
    const elementRects = elements.map((element) => [
      element,
      element.getBoundingClientRect(),
    ]);

    for (const [element, elementRect] of elementRects) {
      if (!pointerActive || reducedMotion.matches) {
        element.style.setProperty("--pointer-x", "50%");
        element.style.setProperty("--pointer-y", "50%");
        element.style.setProperty("--shine-position-x", "50%");
        element.style.setProperty("--tilt-x", "0deg");
        element.style.setProperty("--tilt-y", "0deg");
        continue;
      }

      const localX = clamp(
        (pointerX - elementRect.left) / Math.max(elementRect.width, 1),
        0,
        1,
      );
      const localY = clamp(
        (pointerY - elementRect.top) / Math.max(elementRect.height, 1),
        0,
        1,
      );
      element.style.setProperty("--pointer-x", `${localX * 100}%`);
      element.style.setProperty("--pointer-y", `${localY * 100}%`);
      element.style.setProperty("--shine-position-x", `${20 + localX * 60}%`);

      const centerX = elementRect.left + elementRect.width / 2;
      const centerY = elementRect.top + elementRect.height / 2;
      const normalizedX = clamp(
        (pointerX - centerX) / Math.max(window.innerWidth / 2, 1),
        -1,
        1,
      );
      const normalizedY = clamp(
        (pointerY - centerY) / Math.max(window.innerHeight / 2, 1),
        -1,
        1,
      );
      element.style.setProperty("--tilt-x", `${-normalizedY * LENS.maxTilt}deg`);
      element.style.setProperty("--tilt-y", `${normalizedX * LENS.maxTilt}deg`);
    }
  };

  const scheduleTilt = () => {
    if (tiltFrame === null) tiltFrame = window.requestAnimationFrame(renderTilt);
  };

  const attachElement = (element) => {
    if (dragStates.has(element)) return;
    const dragState = { activePointer: null, pointerOffsetX: 0, pointerOffsetY: 0 };
    dragStates.set(element, dragState);

    const bringToFront = () => {
      topLayer += 1;
      element.style.zIndex = String(topLayer);
    };

    element.addEventListener("focus", bringToFront);
    element.addEventListener("pointerdown", (event) => {
      if (!draggable) return;
      if (event.button !== 0 && event.pointerType === "mouse") return;

      const elementRect = element.getBoundingClientRect();
      dragState.activePointer = event.pointerId;
      dragState.pointerOffsetX = event.clientX - elementRect.left;
      dragState.pointerOffsetY = event.clientY - elementRect.top;
      element.setPointerCapture(event.pointerId);
      element.classList.add("is-dragging");
      elements.forEach((item) => item.classList.toggle("is-selected", item === element));
      onSelectionChange(element);
      bringToFront();
      event.preventDefault();
    });

    element.addEventListener("pointermove", (event) => {
      if (event.pointerId !== dragState.activePointer) return;

      const containerRect = container.getBoundingClientRect();
      const next = clampPosition(
        element,
        container,
        event.clientX - containerRect.left - dragState.pointerOffsetX,
        event.clientY - containerRect.top - dragState.pointerOffsetY,
      );

      element.style.left = `${next.left}px`;
      element.style.top = `${next.top}px`;
      updateAriaValue(element, container, next.left);
      onPositionChange(element);
    });

    const endDrag = (event) => {
      if (event.pointerId !== dragState.activePointer) return;
      dragState.activePointer = null;
      element.classList.remove("is-dragging");
      if (element.hasPointerCapture(event.pointerId)) {
        element.releasePointerCapture(event.pointerId);
      }
    };

    element.addEventListener("pointerup", endDrag);
    element.addEventListener("pointercancel", endDrag);
    element.addEventListener("keydown", (event) => {
      if (!draggable) return;
      const directions = {
        ArrowLeft: [-1, 0],
        ArrowRight: [1, 0],
        ArrowUp: [0, -1],
        ArrowDown: [0, 1],
      };
      const direction = directions[event.key];
      if (!direction) return;

      const step = event.shiftKey ? 24 : 8;
      const currentLeft = Number.parseFloat(
        element.style.left || getComputedStyle(element).left,
      );
      const currentTop = Number.parseFloat(
        element.style.top || getComputedStyle(element).top,
      );
      const next = clampPosition(
        element,
        container,
        currentLeft + direction[0] * step,
        currentTop + direction[1] * step,
      );

      element.style.left = `${next.left}px`;
      element.style.top = `${next.top}px`;
      updateAriaValue(element, container, next.left);
      onPositionChange(element);
      event.preventDefault();
    });
  };

  window.addEventListener("pointermove", (event) => {
    pointerX = event.clientX;
    pointerY = event.clientY;
    pointerActive = true;
    scheduleTilt();
  }, { passive: true });
  window.addEventListener("pointerdown", setPointerInput, { capture: true, passive: true });
  window.addEventListener("keydown", setKeyboardInput, { capture: true });
  document.documentElement.addEventListener("pointerleave", () => {
    pointerActive = false;
    scheduleTilt();
  }, { passive: true });
  window.addEventListener("blur", () => {
    pointerActive = false;
    scheduleTilt();
  });
  reducedMotion.addEventListener("change", scheduleTilt);

  elements.forEach(attachElement);

  const keepInBounds = () => {
    for (const element of elements) {
      const currentLeft = Number.parseFloat(
        element.style.left || getComputedStyle(element).left,
      );
      const currentTop = Number.parseFloat(
        element.style.top || getComputedStyle(element).top,
      );
      const next = clampPosition(element, container, currentLeft, currentTop);
      element.style.left = `${next.left}px`;
      element.style.top = `${next.top}px`;
    }
    scheduleTilt();
  };

  const addElement = (element) => {
    if (!elements.includes(element)) elements.push(element);
    attachElement(element);
    scheduleTilt();
  };

  const removeElement = (element) => {
    const index = elements.indexOf(element);
    if (index >= 0) elements.splice(index, 1);
    dragStates.delete(element);
    scheduleTilt();
  };

  pointerActive = false;
  scheduleTilt();
  return { addElement, keepInBounds, removeElement };
}

return { makeDraggableGroup };
})();

const { captureLayout, applyLayout, pingLayoutController, loadAssetCatalog, getLibraryAssetUrl, loadSavedLayout, saveLayout, openPlacementEditor, closePlacementEditor, openImageLibrary, importImagePack } = (() => {
const CONTROLLER_ORIGIN = "http://127.0.0.1:39271";
const CONTROLLER_HEADER = "X-Trickcal-Controller";

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

function getControllerUrl(path) {
  if (
    location.hostname === "127.0.0.1" &&
    location.pathname.startsWith("/editor")
  ) {
    return path;
  }
  return `${CONTROLLER_ORIGIN}${path}`;
}

async function controllerRequest(path, options = {}) {
  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), options.timeout ?? 1600);
  const {
    timeout: _timeout,
    headers: optionHeaders = {},
    ...fetchOptions
  } = options;
  const hasContentType = Object.keys(optionHeaders)
    .some((name) => name.toLowerCase() === "content-type");
  const shouldUseJson = typeof options.body === "string" && !hasContentType;

  try {
    const response = await fetch(getControllerUrl(path), {
      ...fetchOptions,
      cache: "no-store",
      signal: controller.signal,
      headers: {
        [CONTROLLER_HEADER]: "1",
        ...(shouldUseJson ? { "Content-Type": "application/json" } : {}),
        ...optionHeaders,
      },
    });

    if (!response.ok) {
      throw new Error(`Controller request failed: ${response.status}`);
    }
    return response;
  } finally {
    window.clearTimeout(timeout);
  }
}

function getLayoutBounds(element, container) {
  const rightInset = Number.parseFloat(
    getComputedStyle(container).getPropertyValue("--interaction-right-inset"),
  ) || 0;
  return {
    maxX: Math.max(0, container.clientWidth - rightInset - element.offsetWidth),
    maxY: Math.max(
      0,
      Math.max(container.scrollHeight, window.innerHeight) - element.offsetHeight,
    ),
  };
}

function captureLayout(elements, container) {
  return {
    version: 2,
    updatedAt: new Date().toISOString(),
    objects: elements.map((element) => {
      const { maxX, maxY } = getLayoutBounds(element, container);
      const left = Number.parseFloat(element.style.left) || 0;
      const top = Number.parseFloat(element.style.top) || 0;
      return {
        id: element.dataset.icon,
        asset: element.dataset.asset,
        label: element.dataset.label,
        x: maxX > 0 ? clamp(left / maxX, 0, 1) : 0.5,
        y: maxY > 0 ? clamp(top / maxY, 0, 1) : 0.5,
      };
    }),
  };
}

function applyLayout(layout, elements, container) {
  if (!layout || !Array.isArray(layout.objects)) return false;

  const positions = new Map(layout.objects.map((item) => [item.id, item]));
  let applied = 0;

  for (const element of elements) {
    const position = positions.get(element.dataset.icon);
    if (!position) continue;
    const { maxX, maxY } = getLayoutBounds(element, container);
    element.style.left = `${clamp(Number(position.x) || 0, 0, 1) * maxX}px`;
    element.style.top = `${clamp(Number(position.y) || 0, 0, 1) * maxY}px`;
    applied += 1;
  }

  return applied === layout.objects.length;
}

async function pingLayoutController() {
  const response = await controllerRequest("/api/health", { timeout: 900 });
  return response.json();
}

async function loadSavedLayout() {
  const response = await controllerRequest("/api/layout");
  return response.json();
}

async function loadAssetCatalog() {
  const response = await controllerRequest("/api/catalog", { timeout: 5000 });
  return response.json();
}

function getLibraryAssetUrl(file, revision = "") {
  const encodedPath = String(file ?? "")
    .replaceAll("\\", "/")
    .split("/")
    .map((segment) => encodeURIComponent(segment))
    .join("/");
  const version = revision ? `?v=${encodeURIComponent(revision)}` : "";
  return `${getControllerUrl(`/library/${encodedPath}`)}${version}`;
}

async function saveLayout(layout) {
  const response = await controllerRequest("/api/layout", {
    method: "POST",
    body: JSON.stringify(layout),
    timeout: 3000,
  });
  return response.json();
}

async function openPlacementEditor() {
  const response = await controllerRequest("/api/open-editor", {
    method: "POST",
    timeout: 3000,
  });
  return response.json();
}

async function closePlacementEditor() {
  const response = await controllerRequest("/api/close-editor", {
    method: "POST",
    timeout: 1800,
  });
  return response.json();
}

async function openImageLibrary() {
  const response = await controllerRequest("/api/open-library", {
    method: "POST",
    timeout: 3000,
  });
  return response.json();
}

async function importImagePack(file) {
  const response = await controllerRequest("/api/import-pack", {
    method: "POST",
    body: file,
    headers: { "Content-Type": "application/zip" },
    timeout: 120000,
  });
  return response.json();
}

return { captureLayout, applyLayout, pingLayoutController, loadAssetCatalog, getLibraryAssetUrl, loadSavedLayout, saveLayout, openPlacementEditor, closePlacementEditor, openImageLibrary, importImagePack };
})();

const { getCurrentLensSize, applyParameterPreset, buildFrontSpecularMap, updateSpecularAngle, updateSpecularOpacity, buildPlateWalls } = (() => {
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
let activeSpecularAngle = PARAMETERS.specularAngle;
let activeSpecularOpacity = PARAMETERS.specularOpacity;
let activeFrontSpecularMap = "";

function roundedRectangleSdf(x, y, halfWidth, halfHeight, radius) {
  const qx = Math.abs(x) - (halfWidth - radius);
  const qy = Math.abs(y) - (halfHeight - radius);
  const outside = Math.hypot(Math.max(qx, 0), Math.max(qy, 0));
  const inside = Math.min(Math.max(qx, qy), 0);
  return outside + inside - radius;
}

function getLensGeometry(width, height, cornerRadius, x, y) {
  const cx = width / 2;
  const cy = height / 2;
  const localX = x - cx;
  const localY = y - cy;
  const halfWidth = width / 2 - 1;
  const halfHeight = height / 2 - 1;
  const radius = Math.min(cornerRadius, halfWidth, halfHeight);
  const distance = roundedRectangleSdf(
    localX,
    localY,
    halfWidth,
    halfHeight,
    radius,
  );
  const inside = distance <= 0;
  const edgeDistance = -distance;

  let normalX = 0;
  let normalY = 0;
  if (inside) {
    // The SDF gradient points out of the rounded rectangle and becomes the
    // surface normal used by the rim light.
    const epsilon = 0.5;
    const gradientX =
      roundedRectangleSdf(localX + epsilon, localY, halfWidth, halfHeight, radius) -
      roundedRectangleSdf(localX - epsilon, localY, halfWidth, halfHeight, radius);
    const gradientY =
      roundedRectangleSdf(localX, localY + epsilon, halfWidth, halfHeight, radius) -
      roundedRectangleSdf(localX, localY - epsilon, halfWidth, halfHeight, radius);
    const gradientLength = Math.hypot(gradientX, gradientY);
    if (gradientLength > 0.0001) {
      normalX = gradientX / gradientLength;
      normalY = gradientY / gradientLength;
    }
  }

  return {
    cx,
    cy,
    inside,
    edgeDistance,
    normalX,
    normalY,
  };
}

function createCanvas(width, height) {
  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

function buildSpecularMap(
  width,
  height,
  cornerRadius,
  angle,
  { edgeInset = 0, maximumRimWidth = Math.min(14, height * 0.15) } = {},
) {
  const canvas = createCanvas(width, height);
  const context = canvas.getContext("2d", { willReadFrequently: false });
  const image = context.createImageData(width, height);
  const lightAngle = (angle * Math.PI) / 180;
  const lightX = Math.cos(lightAngle);
  const lightY = Math.sin(lightAngle);
  const minimumRimWidth = Math.min(1, maximumRimWidth);

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const pixel = (y * width + x) * 4;
      const geometry = getLensGeometry(
        width,
        height,
        cornerRadius,
        x + 0.5,
        y + 0.5,
      );
      if (!geometry.inside) continue;

      const normalToLight =
        geometry.normalX * lightX + geometry.normalY * lightY;
      const angularResponse = Math.pow(Math.abs(normalToLight), 1.35);
      const localRimWidth =
        minimumRimWidth +
        (maximumRimWidth - minimumRimWidth) * angularResponse;
      const distanceFromRim = geometry.edgeDistance - edgeInset;
      if (distanceFromRim < 0 || distanceFromRim > localRimWidth) continue;

      const rim = Math.pow(
        clamp(1 - distanceFromRim / localRimWidth, 0, 1),
        1.7,
      );
      const opposingSideStrength = normalToLight < 0 ? 0.9 : 1;
      const intensity =
        Math.pow(angularResponse, 1.7) * rim * opposingSideStrength;

      // The map is fully transparent away from the two opposing rims. Their
      // real pixel width and opacity both taper with angular distance.
      image.data[pixel] = 255;
      image.data[pixel + 1] = 255;
      image.data[pixel + 2] = 255;
      image.data[pixel + 3] = Math.round(255 * intensity);
    }
  }

  context.putImageData(image, 0, 0);
  return canvas.toDataURL("image/png");
}

function setFrontSpecularMap(value) {
  activeFrontSpecularMap = value;
  document
    .querySelectorAll(".magnifier")
    .forEach((magnifier) => {
      magnifier.style.setProperty("--front-specular-map", `url("${value}")`);
    });
}

function getCurrentLensSize() {
  const mobile = window.matchMedia(`(max-width: ${LENS.mobileBreakpoint}px)`).matches;
  return mobile
    ? {
        width: LENS.mobileWidth,
        height: LENS.mobileHeight,
        cornerRadius: LENS.mobileCornerRadius,
      }
    : {
        width: LENS.desktopWidth,
        height: LENS.desktopHeight,
        cornerRadius: LENS.cornerRadius,
      };
}

function applyParameterPreset() {
  document
    .querySelectorAll(".magnifier")
    .forEach((magnifier) => {
      magnifier.style.setProperty("--specular-strength", String(activeSpecularOpacity));
    });
}

function buildFrontSpecularMap() {
  const { width, height, cornerRadius } = getCurrentLensSize();
  const frontSpecular = buildSpecularMap(
    width,
    height,
    cornerRadius,
    activeSpecularAngle,
    { maximumRimWidth: Math.max(3.4, height * 0.016) },
  );

  setFrontSpecularMap(frontSpecular);
  applyParameterPreset();
}

function updateSpecularAngle(angle) {
  activeSpecularAngle = Math.round(clamp(angle, -180, 180));
  const { width, height, cornerRadius } = getCurrentLensSize();
  const frontSpecular = buildSpecularMap(
    width,
    height,
    cornerRadius,
    activeSpecularAngle,
    { maximumRimWidth: Math.max(3.4, height * 0.016) },
  );

  setFrontSpecularMap(frontSpecular);
}

function updateSpecularOpacity(opacity) {
  const strength = clamp(opacity, 0, 3);
  activeSpecularOpacity = strength;
  document
    .querySelectorAll(".magnifier")
    .forEach((magnifier) => {
      magnifier.style.setProperty("--specular-strength", String(strength));
    });
}

function buildPlateWalls(element) {
  const { width, height, cornerRadius } = getCurrentLensSize();
  const depth = width / 5;
  const segmentsPerCorner = 6;
  const segmentAngle = 90 / segmentsPerCorner;
  const halfSegmentRadians = ((segmentAngle / 2) * Math.PI) / 180;
  const chordWidth = 2 * cornerRadius * Math.sin(halfSegmentRadians);
  const radialDistance = cornerRadius * Math.cos(halfSegmentRadians);
  const corners = [
    { centerX: cornerRadius, centerY: cornerRadius, startAngle: 180 },
    { centerX: width - cornerRadius, centerY: cornerRadius, startAngle: 270 },
    { centerX: width - cornerRadius, centerY: height - cornerRadius, startAngle: 0 },
    { centerX: cornerRadius, centerY: height - cornerRadius, startAngle: 90 },
  ];

  element
    .querySelectorAll(".magnifier__wall--corner")
    .forEach((wall) => wall.remove());
  element.style.setProperty("--glass-depth", `${depth}px`);
  element.style.setProperty("--specular-strength", String(activeSpecularOpacity));
  if (activeFrontSpecularMap) {
    element.style.setProperty(
      "--front-specular-map",
      `url("${activeFrontSpecularMap}")`,
    );
  }

  for (const corner of corners) {
    for (let segment = 0; segment < segmentsPerCorner; segment += 1) {
      const middleAngle =
        corner.startAngle + segment * segmentAngle + segmentAngle / 2;
      const radians = (middleAngle * Math.PI) / 180;
      const centerX = corner.centerX + radialDistance * Math.cos(radians);
      const centerY = corner.centerY + radialDistance * Math.sin(radians);
      const wall = document.createElement("span");

      wall.className = "magnifier__wall magnifier__wall--corner";
      wall.setAttribute("aria-hidden", "true");
      wall.style.width = `${chordWidth + 0.4}px`;
      wall.style.height = `${depth}px`;
      wall.style.left = `${centerX - (chordWidth + 0.4) / 2}px`;
      wall.style.top = `${centerY - depth}px`;
      wall.style.transform = `rotateZ(${middleAngle + 90}deg) rotateX(90deg)`;
      element.append(wall);
    }
  }
}

return { getCurrentLensSize, applyParameterPreset, buildFrontSpecularMap, updateSpecularAngle, updateSpecularOpacity, buildPlateWalls };
})();

const study = document.querySelector("#study");
const magnifierTemplate = document.querySelector("#magnifier-template");
const placementToolbar = document.querySelector("#placement-toolbar");
const placementStatus = document.querySelector("#placement-status");
const placementStatusText = document.querySelector("#placement-status-text");
const resetLayoutButton = document.querySelector("#reset-layout");
const cancelLayoutButton = document.querySelector("#cancel-layout");
const saveLayoutButton = document.querySelector("#save-layout");
const objectManager = document.querySelector("#object-manager");
const objectCount = document.querySelector("#object-count");
const assetSearchInput = document.querySelector("#asset-search-input");
const categoryFilter = document.querySelector("#category-filter");
const assetGrid = document.querySelector("#asset-grid");
const assetGridEmpty = document.querySelector("#asset-grid-empty");
const librarySummary = document.querySelector("#library-summary");
const openLibraryButton = document.querySelector("#open-library");
const importPackButton = document.querySelector("#import-pack");
const refreshLibraryButton = document.querySelector("#refresh-library");
const imagePackInput = document.querySelector("#image-pack-input");
const toast = document.querySelector("#toast");
const isPlacementEditor = new URLSearchParams(location.search).get("mode") === "placement";
const magnifiers = [];

document.body.classList.toggle("is-placement-editor", isPlacementEditor);

let toastTimer = null;
let activeLayout = null;
let activeLayoutTimestamp = null;
let layoutDirty = false;
let layoutRevision = 0;
let directSaveTimer = null;
let selectedObjectId = null;
let selectedCategory = "전체";
let assetSearchQuery = "";
let iconAssets = [];
let iconCategories = [];
let assetByFile = new Map();
let catalogFingerprint = "";
let catalogLoaded = false;
let catalogLoading = false;
let objectSequence = 0;
let activeShadowOpacity = 0.2;
let activeShadowBlur = 48;
let initializationPromise = Promise.resolve(false);

function showToast(message, duration = 2800) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.hidden = false;
  toastTimer = window.setTimeout(() => {
    toast.hidden = true;
  }, duration);
}

function normalizeCatalog(catalog) {
  const categories = Array.isArray(catalog?.categories)
    ? catalog.categories.filter((category) => typeof category === "string" && category.trim())
    : [];
  const assets = Array.isArray(catalog?.assets)
    ? catalog.assets.filter((asset) =>
      asset &&
      typeof asset.category === "string" &&
      typeof asset.name === "string" &&
      typeof asset.file === "string")
    : [];
  return { categories, assets };
}

function updateLibrarySummary() {
  if (!isPlacementEditor) return;
  librarySummary.textContent = catalogLoaded
    ? `${iconCategories.length}개 폴더 · ${iconAssets.length}개 이미지`
    : "컨트롤러 연결을 확인해 주세요.";
}

function setCatalogLoading(loading) {
  catalogLoading = loading;
  if (!isPlacementEditor) return;
  refreshLibraryButton.disabled = loading;
  importPackButton.disabled = loading;
  refreshLibraryButton.classList.toggle("is-loading", loading);
  refreshLibraryButton.setAttribute("aria-busy", String(loading));
}

function applyAssetCatalog(catalog, { force = false } = {}) {
  const { categories, assets } = normalizeCatalog(catalog);
  const nextFingerprint = JSON.stringify({
    categories,
    assets: assets.map((asset) => [asset.file, asset.revision ?? ""]),
  });
  if (!force && nextFingerprint === catalogFingerprint) return false;

  catalogFingerprint = nextFingerprint;
  catalogLoaded = true;
  iconCategories = categories;
  iconAssets = assets;
  assetByFile = new Map(assets.map((asset) => [asset.file, asset]));

  if (selectedCategory !== "전체" && !iconCategories.includes(selectedCategory)) {
    selectedCategory = "전체";
  }

  magnifiers.forEach((element) => {
    const asset = assetByFile.get(element.dataset.asset);
    if (!asset) return;
    const image = element.querySelector(".magnifier__image");
    const nextSource = getLibraryAssetUrl(asset.file, asset.revision);
    if (image.src !== nextSource) image.src = nextSource;
  });

  renderCategoryFilter();
  renderAssetLibrary();
  updateLibrarySummary();
  if (activeLayout && !layoutDirty) reconcileLayoutObjects(activeLayout);
  return true;
}

async function refreshAssetCatalog({ announce = false, force = false } = {}) {
  if (catalogLoading) return false;
  setCatalogLoading(true);
  try {
    const catalog = await loadAssetCatalog();
    const changed = applyAssetCatalog(catalog, { force });
    if (announce) {
      showToast(changed ? "이미지 라이브러리를 새로 불러왔습니다." : "이미지 라이브러리가 최신 상태입니다.");
    }
    return true;
  } catch {
    catalogLoaded = false;
    updateLibrarySummary();
    renderAssetLibrary();
    if (announce) showToast("이미지 라이브러리를 불러오지 못했습니다.", 4200);
    return false;
  } finally {
    setCatalogLoading(false);
  }
}

function updatePlacementStatus(message) {
  if (!isPlacementEditor) return;
  placementStatusText.textContent = message;
}

function getRightInset() {
  return Number.parseFloat(
    getComputedStyle(study).getPropertyValue("--interaction-right-inset"),
  ) || 0;
}

function makeObjectId() {
  objectSequence += 1;
  return `object-${Date.now().toString(36)}-${objectSequence.toString(36)}`;
}

function setSelectedObject(element) {
  selectedObjectId = element?.dataset.icon ?? null;
  magnifiers.forEach((item) => {
    item.classList.toggle("is-selected", item === element);
  });
  renderAssetLibrary();

  if (element) {
    element.focus({ preventScroll: true });
    updatePlacementStatus(`${magnifiers.length}개 오브젝트 · ${element.dataset.label} 선택됨`);
  }
}

function createCheckIcon() {
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("aria-hidden", "true");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", "m9.55 16.15-3.7-3.7 1.4-1.4 2.3 2.3 7.2-7.2 1.4 1.4-8.6 8.6Z");
  svg.append(path);
  return svg;
}

function getMagnifiersByAsset(file) {
  return magnifiers.filter((element) => element.dataset.asset === file);
}

function toggleAsset(asset, enabled) {
  const existing = getMagnifiersByAsset(asset.file);
  if (enabled) {
    if (existing.length > 0) {
      setSelectedObject(existing[0]);
      return;
    }

    const magnifier = createMagnifier({
      id: makeObjectId(),
      asset: asset.file,
      label: asset.name,
    });
    if (!magnifier) return;
    placeNewMagnifier(magnifier);
    setSelectedObject(magnifier);
    markLayoutChanged(magnifier);
    showToast(`${asset.name} 오브젝트를 추가했습니다.`);
    return;
  }

  existing.forEach(removeMagnifier);
  markLayoutChanged();
  showToast(`${asset.name} 오브젝트를 해제했습니다. 배치 저장 전까지는 확정되지 않습니다.`);
}

function renderCategoryFilter() {
  if (!isPlacementEditor) return;
  categoryFilter.replaceChildren();

  ["전체", ...iconCategories].forEach((category) => {
    const button = document.createElement("button");
    button.className = "category-filter__button";
    button.type = "button";
    button.textContent = category;
    button.setAttribute("aria-controls", "asset-grid");
    button.setAttribute("aria-pressed", String(category === selectedCategory));
    button.addEventListener("click", () => {
      selectedCategory = category;
      renderCategoryFilter();
      renderAssetLibrary();
    });
    categoryFilter.append(button);
  });
}

function renderAssetLibrary() {
  if (!isPlacementEditor) return;
  objectCount.textContent = String(magnifiers.length);
  assetGrid.replaceChildren();

  const query = assetSearchQuery.trim().toLocaleLowerCase("ko");
  const assets = iconAssets.filter((asset) => {
    const categoryMatches = selectedCategory === "전체" || asset.category === selectedCategory;
    const queryMatches = !query ||
      `${asset.name} ${asset.file} ${asset.category}`.toLocaleLowerCase("ko").includes(query);
    return categoryMatches && queryMatches;
  });

  assetGridEmpty.hidden = assets.length > 0;
  assetGridEmpty.textContent = !catalogLoaded
    ? "이미지 라이브러리를 불러오는 중입니다."
    : query
      ? "검색 결과가 없습니다."
      : "이 폴더에는 이미지가 없습니다.";

  assets.forEach((asset, index) => {
    const element = getMagnifiersByAsset(asset.file)[0] ?? null;
    const item = document.createElement("li");
    const selectButton = document.createElement("button");
    const thumbnail = document.createElement("img");
    const copy = document.createElement("span");
    const name = document.createElement("strong");
    const category = document.createElement("small");
    const toggleLabel = document.createElement("label");
    const toggleInput = document.createElement("input");
    const check = document.createElement("span");
    const active = Boolean(element);
    const focused = element?.dataset.icon === selectedObjectId;

    item.className = "asset-card";
    item.classList.toggle("is-active", active);
    item.classList.toggle("is-focused", focused);
    selectButton.className = "asset-card__select";
    selectButton.type = "button";
    selectButton.disabled = !active;
    selectButton.setAttribute(
      "aria-label",
      active ? `${asset.name} 오브젝트 선택` : `${asset.name} 이미지 미리보기`,
    );
    selectButton.addEventListener("click", () => setSelectedObject(element));

    thumbnail.src = getLibraryAssetUrl(asset.file, asset.revision);
    thumbnail.alt = `${asset.name} 미리보기`;
    thumbnail.loading = index < 6 ? "eager" : "lazy";
    thumbnail.decoding = "async";
    copy.className = "asset-card__copy";
    name.textContent = asset.name;
    category.textContent = asset.category;
    copy.append(name, category);
    selectButton.append(thumbnail, copy);

    toggleLabel.className = "asset-card__toggle";
    toggleInput.type = "checkbox";
    toggleInput.checked = active;
    toggleInput.setAttribute("aria-label", `${asset.name} 오브젝트 사용`);
    check.className = "asset-card__check";
    check.setAttribute("aria-hidden", "true");
    check.append(createCheckIcon());
    toggleInput.addEventListener("change", () => {
      toggleAsset(asset, toggleInput.checked);
    });
    toggleLabel.append(toggleInput, check);

    item.append(selectButton, toggleLabel);
    assetGrid.append(item);
  });
}

const interactionController = makeDraggableGroup([], study, {
  draggable: true,
  onPositionChange: markLayoutChanged,
  onSelectionChange: setSelectedObject,
});

function createMagnifier(object) {
  const asset = assetByFile.get(object.asset);
  if (!asset) return null;

  const magnifier = magnifierTemplate.content.firstElementChild.cloneNode(true);
  const image = magnifier.querySelector(".magnifier__image");
  const label = object.label || asset.name;

  magnifier.dataset.icon = object.id;
  magnifier.dataset.asset = asset.file;
  magnifier.dataset.label = label;
  magnifier.setAttribute("aria-label", `${label} 오브젝트 이동`);
  image.src = getLibraryAssetUrl(asset.file, asset.revision);
  image.decoding = "async";
  image.loading = magnifiers.length < 4 ? "eager" : "lazy";
  magnifier.style.setProperty("--shadow-opacity", String(activeShadowOpacity));
  magnifier.style.setProperty("--shadow-blur", `${activeShadowBlur}px`);

  magnifiers.push(magnifier);
  study.append(magnifier);
  buildPlateWalls(magnifier);
  interactionController.addElement(magnifier);
  return magnifier;
}

function removeMagnifier(element) {
  const index = magnifiers.indexOf(element);
  if (index >= 0) magnifiers.splice(index, 1);
  interactionController.removeElement(element);
  element.remove();
  if (selectedObjectId === element.dataset.icon) selectedObjectId = null;
  renderAssetLibrary();
}

function arrangeMagnifiers() {
  if (magnifiers.length === 0) {
    study.style.minHeight = "100svh";
    return;
  }

  const lensWidth = magnifiers[0].offsetWidth;
  const lensHeight = magnifiers[0].offsetHeight;
  const gap = lensWidth <= 200 ? 18 : 24;
  const sidePadding = lensWidth <= 200 ? 16 : 32;
  const topInset = isPlacementEditor ? 104 : 48;
  const bottomInset = isPlacementEditor ? 64 : 48;
  const usableWidth = Math.max(
    lensWidth,
    study.clientWidth - getRightInset() - sidePadding * 2,
  );
  const fittingColumns = Math.max(
    1,
    Math.floor((usableWidth + gap) / (lensWidth + gap)),
  );
  const columns = Math.min(4, fittingColumns, magnifiers.length);
  const rows = Math.ceil(magnifiers.length / columns);
  const gridWidth = columns * lensWidth + (columns - 1) * gap;
  const gridHeight = rows * lensHeight + (rows - 1) * gap;
  const contentWidth = study.clientWidth - getRightInset();
  const startX = Math.max(0, (contentWidth - gridWidth) / 2);
  const usableHeight = window.innerHeight - topInset - bottomInset;
  const startY = gridHeight <= usableHeight
    ? topInset + Math.max(0, (usableHeight - gridHeight) / 2)
    : topInset;

  study.style.minHeight = `${Math.max(
    window.innerHeight,
    startY + gridHeight + bottomInset,
  )}px`;

  magnifiers.forEach((magnifier, index) => {
    const column = index % columns;
    const row = Math.floor(index / columns);
    magnifier.style.left = `${startX + column * (lensWidth + gap)}px`;
    magnifier.style.top = `${startY + row * (lensHeight + gap)}px`;
  });
}

function placeNewMagnifier(element) {
  const maxX = Math.max(0, study.clientWidth - getRightInset() - element.offsetWidth);
  const maxY = Math.max(0, window.innerHeight - element.offsetHeight);
  const cascade = ((magnifiers.length - 1) % 7) * 18;
  element.style.left = `${Math.min(maxX, Math.max(0, maxX / 2 + cascade - 54))}px`;
  element.style.top = `${Math.min(maxY, Math.max(0, maxY / 2 + cascade - 54))}px`;
}

async function persistDirectLayout(layout, revision) {
  try {
    const saved = await saveLayout(layout);
    if (revision !== layoutRevision) return;
    activeLayout = saved.layout ?? layout;
    activeLayoutTimestamp = activeLayout.updatedAt;
    layoutDirty = false;
  } catch {
    // Direct dragging still works when the optional controller is offline.
  }
}

function scheduleDirectLayoutSave() {
  if (isPlacementEditor) return;
  window.clearTimeout(directSaveTimer);
  directSaveTimer = window.setTimeout(() => {
    const layout = captureLayout(magnifiers, study);
    void persistDirectLayout(layout, layoutRevision);
  }, 320);
}

function markLayoutChanged(selectedElement) {
  activeLayout = captureLayout(magnifiers, study);
  activeLayoutTimestamp = activeLayout.updatedAt;
  layoutDirty = true;
  layoutRevision += 1;
  scheduleDirectLayoutSave();
  updatePlacementStatus(
    `${magnifiers.length}개 오브젝트 · ${selectedElement?.dataset.label ?? "목록"} 수정됨`,
  );
}

function reconcileLayoutObjects(layout) {
  const seenAssets = new Set();
  const objects = layout.objects.filter((object) => {
    if (!assetByFile.has(object.asset) || seenAssets.has(object.asset)) return false;
    seenAssets.add(object.asset);
    return true;
  });
  const nextIds = new Set(objects.map((object) => object.id));

  [...magnifiers].forEach((element) => {
    if (!nextIds.has(element.dataset.icon)) removeMagnifier(element);
  });

  const existingById = new Map(magnifiers.map((element) => [element.dataset.icon, element]));
  objects.forEach((object) => {
    if (!existingById.has(object.id)) createMagnifier(object);
  });

  const order = new Map(objects.map((object, index) => [object.id, index]));
  magnifiers.sort(
    (left, right) => order.get(left.dataset.icon) - order.get(right.dataset.icon),
  );
  renderAssetLibrary();
  updatePlacementStatus(`${magnifiers.length}개 오브젝트 · 변경사항 없음`);
  return applyLayout({ ...layout, objects }, magnifiers, study);
}

async function syncSavedLayout({ silent = true } = {}) {
  try {
    const layout = await loadSavedLayout();
    if (!layout || layout.version < 2 || !Array.isArray(layout.objects)) return false;
    if (layout.updatedAt && layout.updatedAt === activeLayoutTimestamp) return true;
    if (layoutDirty) return true;

    if (reconcileLayoutObjects(layout)) {
      activeLayout = layout;
      activeLayoutTimestamp = layout.updatedAt ?? null;
      if (!silent) showToast("저장된 오브젝트 배치를 불러왔습니다.");
      return true;
    }
  } catch {
    if (!silent) showToast("배치 컨트롤러에 연결할 수 없습니다.");
  }
  return false;
}

async function launchPlacementEditor() {
  try {
    await openPlacementEditor();
    showToast("오브젝트 관리 창을 열었습니다.");
  } catch {
    showToast("배치 컨트롤러를 먼저 설치하고 실행해 주세요.", 4200);
  }
}

createBackgroundRenderer(document.querySelector("#background-canvas"));
buildFrontSpecularMap();

if (isPlacementEditor) {
  placementToolbar.hidden = false;
  placementStatus.hidden = false;
  objectManager.hidden = false;
  renderCategoryFilter();
  renderAssetLibrary();
  updateLibrarySummary();
  updatePlacementStatus("0개 오브젝트 · 변경사항 없음");

  assetSearchInput.addEventListener("input", () => {
    assetSearchQuery = assetSearchInput.value;
    renderAssetLibrary();
  });

  openLibraryButton.addEventListener("click", async () => {
    openLibraryButton.disabled = true;
    try {
      await openImageLibrary();
      showToast("이미지 라이브러리 폴더를 열었습니다.");
    } catch {
      showToast("이미지 폴더를 열지 못했습니다.", 4200);
    } finally {
      openLibraryButton.disabled = false;
    }
  });

  importPackButton.addEventListener("click", () => imagePackInput.click());

  imagePackInput.addEventListener("change", async () => {
    const [file] = imagePackInput.files;
    imagePackInput.value = "";
    if (!file) return;
    if (!file.name.toLocaleLowerCase("ko").endsWith(".zip")) {
      showToast("ZIP 형식의 이미지 팩을 선택해 주세요.", 4200);
      return;
    }
    if (file.size > 128 * 1024 * 1024) {
      showToast("이미지 팩은 128MB 이하여야 합니다.", 4200);
      return;
    }

    setCatalogLoading(true);
    importPackButton.classList.add("is-loading");
    importPackButton.setAttribute("aria-busy", "true");
    try {
      const result = await importImagePack(file);
      applyAssetCatalog(result.catalog, { force: true });
      showToast(`${result.imported}개 이미지를 라이브러리에 가져왔습니다.`);
    } catch {
      showToast("이미지 팩을 가져오지 못했습니다. ZIP 구조를 확인해 주세요.", 4800);
    } finally {
      importPackButton.classList.remove("is-loading");
      importPackButton.setAttribute("aria-busy", "false");
      setCatalogLoading(false);
    }
  });

  refreshLibraryButton.addEventListener("click", () => {
    void refreshAssetCatalog({ announce: true, force: true });
  });

  study.addEventListener("pointerdown", (event) => {
    if (event.target !== study) return;
    setSelectedObject(null);
    updatePlacementStatus(
      `${magnifiers.length}개 오브젝트 · ${layoutDirty ? "저장되지 않은 변경사항" : "변경사항 없음"}`,
    );
  });

  resetLayoutButton.addEventListener("click", () => {
    arrangeMagnifiers();
    setSelectedObject(null);
    markLayoutChanged();
    showToast("오브젝트를 격자 형태로 정렬했습니다.");
  });

  cancelLayoutButton.addEventListener("click", async () => {
    cancelLayoutButton.disabled = true;
    try {
      await closePlacementEditor();
    } catch {
      window.close();
    }
  });

  saveLayoutButton.addEventListener("click", async () => {
    saveLayoutButton.disabled = true;
    const layout = captureLayout(magnifiers, study);
    try {
      const saved = await saveLayout(layout);
      activeLayout = saved.layout ?? layout;
      activeLayoutTimestamp = activeLayout.updatedAt;
      layoutDirty = false;
      updatePlacementStatus(`${magnifiers.length}개 오브젝트 · 저장 완료`);
      showToast("오브젝트 목록과 배치를 저장했습니다.");
      window.setTimeout(() => closePlacementEditor().catch(() => window.close()), 550);
    } catch {
      saveLayoutButton.disabled = false;
      showToast("저장하지 못했습니다. 컨트롤러 연결을 확인해 주세요.", 4200);
    }
  });
} else {
  window.setInterval(() => syncSavedLayout(), 2400);
  window.setInterval(() => refreshAssetCatalog(), 10000);
}

initializationPromise = refreshAssetCatalog().then(() => syncSavedLayout({ silent: true })).then((loaded) => {
  if (!loaded) {
    activeLayout = { version: 2, updatedAt: null, objects: [] };
    arrangeMagnifiers();
    renderAssetLibrary();
  }
  return loaded;
});

function updateShadowOpacity(value) {
  activeShadowOpacity = Math.min(0.6, Math.max(0, value));
  magnifiers.forEach((magnifier) => {
    magnifier.style.setProperty("--shadow-opacity", String(activeShadowOpacity));
  });
}

function updateShadowBlur(value) {
  activeShadowBlur = Math.min(90, Math.max(0, value));
  magnifiers.forEach((magnifier) => {
    magnifier.style.setProperty("--shadow-blur", `${activeShadowBlur}px`);
  });
}

window.livelyPropertyListener = (name, value) => {
  const numericValue = Number(value);

  switch (name) {
    case "openPlacementEditor":
      void launchPlacementEditor();
      break;
    case "specularHighlight":
      if (Number.isFinite(numericValue)) updateSpecularOpacity(numericValue / 100);
      break;
    case "specularAngle":
      if (Number.isFinite(numericValue)) updateSpecularAngle(numericValue);
      break;
    case "shadowOpacity":
      if (Number.isFinite(numericValue)) updateShadowOpacity(numericValue / 100);
      break;
    case "shadowBlur":
      if (Number.isFinite(numericValue)) updateShadowBlur(numericValue);
      break;
    default:
      break;
  }
};

let lastMobileState = window.matchMedia("(max-width: 760px)").matches;
window.addEventListener("resize", () => {
  const mobileState = window.matchMedia("(max-width: 760px)").matches;
  if (mobileState !== lastMobileState) {
    lastMobileState = mobileState;
    buildFrontSpecularMap();
    magnifiers.forEach(buildPlateWalls);
  }

  if (activeLayout) {
    applyLayout(activeLayout, magnifiers, study);
  } else {
    interactionController.keepInBounds();
  }
}, { passive: true });
})();
